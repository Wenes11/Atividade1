import javax.swing.JOptionPane;
public class Ex02{
    public static void main(String[] args) {
  String algo="Aprendenddo algoritmo!!!";
  JOptionPane.showMessageDialog(null,algo   + "Com anita e Guto");

    }
}