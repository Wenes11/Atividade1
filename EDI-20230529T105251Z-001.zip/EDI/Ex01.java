import javax.swing.JOptionPane;
public class Ex01{
    public static void main(String[] args) {
  String algo="Aprendenddo algoritmo!!!";
  JOptionPane.showMessageDialog(null,algo);

    }
}