import javax.swing.JOptionPane;
public class Ex04 {
    public static void main(String[] args) {
        int num=10;
        JOptionPane.showMessageDialog(null,"O Valor de x : "  + (num+1));
    }
}
