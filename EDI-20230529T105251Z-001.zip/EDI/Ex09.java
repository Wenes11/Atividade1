import javax.swing.JOptionPane;
public class Ex09 {
    public static void main(String[] args) {
        float media;
        media= (8+9+7)/3;
        JOptionPane.showMessageDialog(null," \n A media Aritimetica e : \n" + media);

    }
}
