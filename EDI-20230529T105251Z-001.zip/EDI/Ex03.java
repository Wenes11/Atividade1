import javax.swing.JOptionPane;
public class Ex03 {
    public static void main(String[] args) {
       int num=10;
        JOptionPane.showMessageDialog(null,num);
    }
}
